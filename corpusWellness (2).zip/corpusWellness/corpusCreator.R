# First part is creating the corpus directory from the 204 groupon reviews



wellness <- read.csv('WellnessReviews92879search10312019.csv', sep=',', header=TRUE, 
                     na.strings=c('','NA'))

#dir.create('corpusWellness')
#store this file above and the csv file above here in folder just created


library(dplyr)

dir.create('5')
dir.create('4')
dir.create('3')
dir.create('2')
dir.create('1')

sentimentGroup <- wellness %>% group_by(sentiment) %>% summarise(n=n())

sentiment5 <- filter(wellness, sentiment=='5')
sentiment4 <- filter(wellness, sentiment=='4')
sentiment3 <- filter(wellness, sentiment=='3')
sentiment2 <- filter(wellness, sentiment=='2')
sentiment1 <- filter(wellness, sentiment=='1')

s5 <- data.frame(sentiment5[,1])#178X1
colnames(s5) <- 'review'

#set directory to '5' then run the following for 178 reviews with a 5 rating
write.table(s5[1,], '1.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[2,], '2.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[3,], '3.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[4,], '4.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[5,], '5.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[6,], '6.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[7,], '7.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[8,], '8.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[9,], '9.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[10,], '10.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[11,], '11.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[12,], '12.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[13,], '13.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[14,], '14.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[15,], '15.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[16,], '16.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[17,], '17.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[18,], '18.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[19,], '19.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[20,], '20.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[21,], '21.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[22,], '22.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[23,], '23.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[24,], '24.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[25,], '25.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[26,], '26.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[27,], '27.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[28,], '28.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[29,], '29.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[30,], '30.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[31,], '31.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[32,], '32.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[33,], '33.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[34,], '34.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[35,], '35.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[36,], '36.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[37,], '37.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[38,], '38.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[39,], '39.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[40,], '40.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[41,], '41.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[42,], '42.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[43,], '43.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[44,], '44.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[45,], '45.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[46,], '46.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[47,], '47.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[48,], '48.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[49,], '49.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[50,], '50.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[51,], '51.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[52,], '52.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[53,], '53.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[54,], '54.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[55,], '55.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[56,], '56.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[57,], '57.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[58,], '58.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[59,], '59.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[60,], '60.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[61,], '61.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[62,], '62.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[63,], '63.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[64,], '64.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[65,], '65.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[66,], '66.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[67,], '67.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[68,], '68.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[69,], '69.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[71,], '71.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[72,], '72.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[73,], '73.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[74,], '74.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[75,], '75.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[76,], '76.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[77,], '77.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[78,], '78.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[79,], '79.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[80,], '80.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[91,], '91.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[92,], '92.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[93,], '93.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[94,], '94.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[95,], '95.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[96,], '96.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[97,], '97.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[98,], '98.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[99,], '99.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[100,], '100.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[101,], '101.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[102,], '102.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[103,], '103.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[104,], '104.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[105,], '105.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[106,], '106.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[107,], '107.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[108,], '108.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[109,], '109.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[110,], '110.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[111,], '111.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[112,], '112.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[113,], '113.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[114,], '114.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[115,], '115.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[116,], '116.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[117,], '117.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[118,], '118.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[119,], '119.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[120,], '120.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[121,], '121.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[122,], '122.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[123,], '123.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[124,], '124.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[125,], '125.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[126,], '126.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[127,], '127.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[128,], '128.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[129,], '129.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[130,], '130.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[131,], '131.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[132,], '132.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[133,], '133.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[134,], '134.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[135,], '135.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[136,], '136.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[137,], '137.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[138,], '138.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[139,], '139.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[140,], '140.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[141,], '141.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[142,], '142.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[143,], '143.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[144,], '144.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[145,], '145.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[146,], '146.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[147,], '147.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[148,], '148.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[149,], '149.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[150,], '150.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[151,], '151.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[152,], '152.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[153,], '153.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[154,], '154.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[155,], '155.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[156,], '156.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[157,], '157.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[158,], '158.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[159,], '159.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[160,], '160.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[161,], '161.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[162,], '162.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[163,], '163.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[164,], '164.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[165,], '165.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[166,], '166.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[167,], '167.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[168,], '168.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[169,], '169.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[170,], '170.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[171,], '171.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[172,], '172.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[173,], '173.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[174,], '174.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[175,], '175.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[176,], '176.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[177,], '177.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s5[178,], '178.txt', sep=',',row.names=FALSE, col.names=FALSE)

s4 <- data.frame(sentiment4[,1])#18X1
colnames(s4) <- 'review'

#set directory to '4' then run the following for 18 reviews with a 4 rating
write.table(s4[1,], '1.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[2,], '2.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[3,], '3.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[4,], '4.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[5,], '5.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[6,], '6.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[7,], '7.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[8,], '8.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[9,], '9.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[10,], '10.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[11,], '11.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[12,], '12.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[13,], '13.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[14,], '14.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[15,], '15.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[16,], '16.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[17,], '17.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s4[18,], '18.txt', sep=',',row.names=FALSE, col.names=FALSE)

s3 <- data.frame(sentiment3[,1])#4X1
colnames(s3) <- 'review'

#set directory to '3' then run the following for 4 reviews with a 3 rating
write.table(s3[1,], '1.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s3[2,], '2.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s3[3,], '3.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s3[4,], '4.txt', sep=',',row.names=FALSE, col.names=FALSE)

s2 <- data.frame(sentiment2[,1])#2X1
colnames(s2) <- 'review'

#set directory to '2' then run the following for 2 reviews with a 2 rating
write.table(s2[1,], '1.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s2[2,], '2.txt', sep=',',row.names=FALSE, col.names=FALSE)

s1 <- data.frame(sentiment1[,1])#3X1
colnames(s1) <- 'review'

#set directory to '1' then run the following for 3 reviews with a 1 rating
write.table(s3[1,], '1.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s3[2,], '2.txt', sep=',',row.names=FALSE, col.names=FALSE)
write.table(s3[3,], '3.txt', sep=',',row.names=FALSE, col.names=FALSE)


########################################################################################


library(tm)
library(SnowballC)
library(wordcloud)
library(ggplot2)



rated5 <- Corpus(DirSource("5"))


rated5
# <<SimpleCorpus>>
#   Metadata:  corpus specific: 1, document level (indexed): 0
# Content:  documents: 167

rated5 <- tm_map(rated5, removePunctuation)
rated5 <- tm_map(rated5, removeNumbers)
rated5 <- tm_map(rated5, tolower)
rated5 <- tm_map(rated5, removeWords, stopwords("english"))
rated5 <- tm_map(rated5, stripWhitespace)
rated5 <- tm_map(rated5, stemDocument)

dtmEmp <- DocumentTermMatrix(rated5)
dtmEmp
# <<DocumentTermMatrix (documents: 167, terms: 610)>>
#   Non-/sparse entries: 1844/100026
# Sparsity           : 98%
# Maximal term length: 13
# Weighting          : term frequency (tf)

freq <- colSums(as.matrix(dtmEmp))

ord <- order(freq, decreasing=TRUE)

freq[head(ord, 25)]
# massag     great      amaz     relax      back    experi     place      love   definit      will 
# 76        56        48        47        36        36        32        28        28        27 
# spa      best     staff    wonder recommend      nice    friend    servic     excel      felt 
# 27        24        22        19        19        18        17        16        14        13 
# facial       day     clean      feel  knowledg 
# 13        13        12        12        12 

findAssocs(dtmEmp, "massag", corlimit=0.3)
# $massag
# nap himalayan     stone       put    honest complaint   convers      door     howev    injuri 
# 0.44      0.33      0.33      0.32      0.31      0.31      0.31      0.31      0.31      0.31 
# knee       leg    louder  movement      play     tight    exceed    fallen   forward      home 
# 0.31      0.31      0.31      0.31      0.31      0.31      0.31      0.31      0.31      0.31 
# luckili       man 
# 0.31      0.31 

findAssocs(dtmEmp, "masseuse", corlimit = 0.1)
# $masseuse
# numeric(0)

findAssocs(dtmEmp, "amaz", corlimit=0.2)
# $amaz
# fell     start       lot     world     treat      deep  greatest     paper      rose     sleep 
# 0.26      0.26      0.25      0.25      0.25      0.25      0.25      0.25      0.25      0.25 
# sweet     tissu     arriv    dollar  fountain     greet     hotel      hung loveliest  spotless 
# 0.25      0.25      0.25      0.25      0.25      0.25      0.25      0.25      0.25      0.25 
# upon      kika       qas   absolut atmospher      food     worth 
# 0.25      0.25      0.25      0.24      0.24      0.22      0.21 

findAssocs(dtmEmp, "experi", corlimit=0.2)
# $experi
# overal   ambienc boyfriend     exist     known premassag    sooner    wouldv    custom    provid 
# 0.38      0.33      0.33      0.33      0.33      0.33      0.33      0.33      0.29      0.25 
# ladi  champagn    chocol    attent   essenti 
# 0.25      0.20      0.20      0.20      0.20 

findAssocs(dtmEmp, "friend", corlimit=0.2)
# $friend
# employe        inform       weekend          went         staff         peopl        mother 
# 0.48          0.38          0.31          0.31          0.25          0.24          0.24 
# person         sooth         truli       correct          katz       present       ambianc 
# 0.24          0.22          0.22          0.22          0.22          0.22          0.22 
# cellular         detox          girl          icon         ultim      christin       lighter 
# 0.22          0.22          0.22          0.22          0.22          0.22          0.22 
# make         refer           two mediterranean           min           pod          rock 
# 0.22          0.22          0.22          0.22          0.22          0.22          0.22 
# bake        fourth          shop          wrap       abdomin        behind       compani 
# 0.22          0.22          0.22          0.22          0.22          0.22          0.22 
# gastro         grace         insid          issu         metal         sheet         spine 
# 0.22          0.22          0.22          0.22          0.22          0.22          0.22 
# typic          unit 
# 0.22          0.22 

wf <- data.frame(word=names(freq), freq=freq)
p <- ggplot(subset(wf, freq>25), aes(word, freq))
p <- p + geom_bar(stat= 'identity') 
p <- p + theme(axis.text.x=element_text(angle=90, hjust=1)) 
p

wordcloud(names(freq), freq, min.freq=20,colors=brewer.pal(3,'Dark2')) #words with 30+ freq
wordcloud(names(freq), freq, max.words=50,colors=brewer.pal(6,'Dark2')) #top 50 words


##########################################################################################
rated4 <- Corpus(DirSource("4"))


rated4

rated4 <- tm_map(rated4, removePunctuation)
rated4 <- tm_map(rated4, removeNumbers)
rated4 <- tm_map(rated4, tolower)
rated4 <- tm_map(rated4, removeWords, stopwords("english"))
rated4 <- tm_map(rated4, stripWhitespace)
rated4 <- tm_map(rated4, stemDocument)

dtmEmp <- DocumentTermMatrix(rated4)
dtmEmp

freq <- colSums(as.matrix(dtmEmp))

ord <- order(freq, decreasing=TRUE)

freq[head(ord, 25)]

findAssocs(dtmEmp, "massag", corlimit=0.3)

findAssocs(dtmEmp, "great", corlimit=0.1)

findAssocs(dtmEmp, "experi", corlimit=0.2)

findAssocs(dtmEmp, "friend", corlimit=0.2)

wf <- data.frame(word=names(freq), freq=freq)
p <- ggplot(subset(wf, freq>2), aes(word, freq))
p <- p + geom_bar(stat= 'identity') 
p <- p + theme(axis.text.x=element_text(angle=90, hjust=1)) 
p

wordcloud(names(freq), freq, min.freq=20,colors=brewer.pal(3,'Dark2')) #words with 30+ freq
wordcloud(names(freq), freq, max.words=50,colors=brewer.pal(6,'Dark2')) #top 50 words

#############################################################################################

rated3 <- Corpus(DirSource("3"))


rated3

rated3 <- tm_map(rated3, removePunctuation)
rated3 <- tm_map(rated3, removeNumbers)
rated3 <- tm_map(rated3, tolower)
rated3 <- tm_map(rated3, removeWords, stopwords("english"))
rated3 <- tm_map(rated3, stripWhitespace)
rated3 <- tm_map(rated3, stemDocument)

dtmEmp <- DocumentTermMatrix(rated3)
dtmEmp

freq <- colSums(as.matrix(dtmEmp))

ord <- order(freq, decreasing=TRUE)

freq[head(ord, 25)]

findAssocs(dtmEmp, "massag", corlimit=0.3)

findAssocs(dtmEmp, "great", corlimit=0.1)

findAssocs(dtmEmp, "experi", corlimit=0.2)

findAssocs(dtmEmp, "friend", corlimit=0.2)

wf <- data.frame(word=names(freq), freq=freq)
p <- ggplot(subset(wf, freq>2), aes(word, freq))
p <- p + geom_bar(stat= 'identity') 
p <- p + theme(axis.text.x=element_text(angle=90, hjust=1)) 
p

wordcloud(names(freq), freq, min.freq=20,colors=brewer.pal(3,'Dark2')) #words with 30+ freq
wordcloud(names(freq), freq, max.words=50,colors=brewer.pal(6,'Dark2')) #top 50 words

#############################################################################################

rated2 <- Corpus(DirSource("2"))


rated2

rated2 <- tm_map(rated2, removePunctuation)
rated2 <- tm_map(rated2, removeNumbers)
rated2 <- tm_map(rated2, tolower)
rated2 <- tm_map(rated2, removeWords, stopwords("english"))
rated2 <- tm_map(rated2, stripWhitespace)
rated2 <- tm_map(rated2, stemDocument)

dtmEmp <- DocumentTermMatrix(rated2)
dtmEmp

freq <- colSums(as.matrix(dtmEmp))

ord <- order(freq, decreasing=TRUE)

freq[head(ord, 25)]

findAssocs(dtmEmp, "massag", corlimit=0.3)

findAssocs(dtmEmp, "great", corlimit=0.1)

findAssocs(dtmEmp, "experi", corlimit=0.2)

findAssocs(dtmEmp, "friend", corlimit=0.2)

wf <- data.frame(word=names(freq), freq=freq)
p <- ggplot(subset(wf, freq>2), aes(word, freq))
p <- p + geom_bar(stat= 'identity') 
p <- p + theme(axis.text.x=element_text(angle=90, hjust=1)) 
p

wordcloud(names(freq), freq, min.freq=20,colors=brewer.pal(3,'Dark2')) 
wordcloud(names(freq), freq, max.words=50,colors=brewer.pal(6,'Dark2')) 


#############################################################################################

rated1 <- Corpus(DirSource("1"))


rated1

rated1 <- tm_map(rated1, removePunctuation)
rated1 <- tm_map(rated1, removeNumbers)
rated1 <- tm_map(rated1, tolower)
rated1 <- tm_map(rated1, removeWords, stopwords("english"))
rated1 <- tm_map(rated1, stripWhitespace)
rated1 <- tm_map(rated1, stemDocument)

dtmEmp <- DocumentTermMatrix(rated1)
dtmEmp

freq <- colSums(as.matrix(dtmEmp))

ord <- order(freq, decreasing=TRUE)

freq[head(ord, 25)]

findAssocs(dtmEmp, "massag", corlimit=0.3)

findAssocs(dtmEmp, "great", corlimit=0.1)

findAssocs(dtmEmp, "experi", corlimit=0.2)

findAssocs(dtmEmp, "friend", corlimit=0.2)

wf <- data.frame(word=names(freq), freq=freq)
p <- ggplot(subset(wf, freq>2), aes(word, freq))
p <- p + geom_bar(stat= 'identity') 
p <- p + theme(axis.text.x=element_text(angle=90, hjust=1)) 
p

wordcloud(names(freq), freq, min.freq=20,colors=brewer.pal(3,'Dark2')) 
wordcloud(names(freq), freq, max.words=50,colors=brewer.pal(6,'Dark2')) 
